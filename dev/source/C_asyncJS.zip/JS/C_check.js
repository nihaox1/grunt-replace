/*!
 *	
 */
$.fn.extend({
	/*!
	-****************************************-
		前端验证输入是否合理插件
		input : _rule="length[0,255] number email pwd"
		jQuery().check( args );
		args = {
			render : function( modal , pass , error_content , args ){
				
				return modal
			}
		};
	-****************************************-
	 */
	check : function( args_config ){
		var self = jQuery(this),
			list = {},
			tool,
			rule,
			args_config = args_config || {},
			manager;
			
		Reg = {
			text : /\w*\[(\d*)\,{0,1}(\d*)\]/g,
			email : /[\w,\d]*\@[\w,\d]*\.[\w,\d]*/g
		};
		
		tool = {
			check : function( modal , args ){
				var _rule = args.rule.split(" "),
					_pass = true;
				for(var i = 0 , len = _rule.length; i < len; i++){
					var _r = _rule[ i ];
					if( _r.indexOf("length") != -1 ){
						var _str = _r.replace( Reg.text , "$1-$2"  );
						if( !tool.text_length( modal.val() , _str ) ){
							_pass = false;
							break;
						};
					} else if( _r.indexOf("email") != -1 ){
						if( !tool.text_email( modal.val() ) ){
							_pass = false;
							break;
						};
					} else if( _r.indexOf("number") != -1 ){
						if( !tool.text_number( modal.val() ) ){
							_pass = false;
							break;
						};
					} else if( _r.indexOf("pwd") != -1 ){
						if( !tool.text_pwd( modal.val() ) ){
							_pass = false;
							break;
						};
					};
				};
				args.pass = _pass;
			},
			text_email : function( string ){
				string = string.replace( Reg.email , "" );
				if( string !== "" ){
					return false;
				};
				return true;
			},
			text_number : function( string ){
				return !isNaN( parseFloat( string ) ) && isFinite( string );
			},
			text_pwd : function( string ){
				var _reg = [ /[a-z]+/g , /[A-Z]+/g , /\d+/g , /[^\d|^\w]+/g ];
				for(var i = 0 , len = _reg.length; i < len; i++){
					if( string.replace( _reg[ i ] , "" ) == string ){
						return false;
					};
				};
				return true;
			},
			text_length : function( string , length ){
				var _len = string.split("").length;
				length = length.split("-");
				if( _len < length[0] ){
					return false;
				};
				if( length[1] !== "" && _len > length[1] ){
					return false;
				};
				return true;
			},
			blur : function( modal , args ){
				var _timeout_time = new Date(),
					_timeout_event;
				function x(){
					var _rule = args.rule.split(" "),
						_pass = true;
					for(var i = 0 , len = _rule.length; i < len; i++){
						var _r = _rule[ i ];
						if( _r.indexOf("length") != -1 ){
							var _str = _r.replace( Reg.text , "$1-$2"  );
							if( !tool.text_length( modal.val() , _str ) ){
								_pass = false;
								break;
							};
						} else if( _r.indexOf("email") != -1 ){
							if( !tool.text_email( modal.val() ) ){
								_pass = false;
								break;
							};
						} else if( _r.indexOf("number") != -1 ){
							if( !tool.text_number( modal.val() ) ){
								_pass = false;
								break;
							};
						} else if( _r.indexOf("pwd") != -1 ){
							if( !tool.text_pwd( modal.val() ) ){
								_pass = false;
								break;
							};
						};
					};
					args.pass = _pass;
					if( args_config.render ){
						args_config.render( modal , _pass , args.content , args );
					};
				};
				modal.unbind("blur").blur(function(){
					window.clearTimeout( _timeout_event );
					_timeout_event = window.setTimeout( function(){ x(); } , 100 );
				});
			},
			set_to_list : function(){
				var _index = 0;
				self.find("input").each(function(){
					var _t = jQuery(this),
						_content = _t.attr("_content") || "";
					_index++;
					list[_index] = {
						rule 	: 	_t.attr("_rule") || "length[0]",
						content : 	_content,
						modal 	: 	_t,
						index 	: 	_index,
						pass 	: 	false
					};
					_t.attr({ _check_id : _index });
					tool.blur( _t , list[_index] );
				});
				list.length = _index;
			},
			init : function(){
				tool.set_to_list();
			}
		};
		tool.init();
		return manager = {
			/*!
			 *	detail : true | false
			 *	false : 仅返回 填写信息 是否正确	
			 *	true  : 返回带错误信息的 数组   如果全部通过 则返回false
			 */
			error : function( detail ){
				var _error = [];
				for(var i = 1 , len = list.length; i <= len; i++){
					tool.check( list[i].modal , list[i] );
					if( !list[i].pass ){
						if( detail ){
							_error.push( list[ i ] );
						} else {
							return true;
						};
					};
				};
				return _error.length ? _error : false;
			}
		};
	}
});