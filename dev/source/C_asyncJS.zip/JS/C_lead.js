﻿$c.extend({
	lead : (function(){
		var tool,
			manage,
			ui,
			html,
			lead,
			inner = {
				theme 		: 	{ "default" : 1 , info : 1 , success : 1 , danger : 1 , warning : 1 , primary : 1 }
			};
			config = {
				theme 		: 	"default",
				title 		: 	"导航",
				drag 		: 	false,
				leads 		: 	{ length : 0 },
				move 		: 	true,
				/*	滑动的动画效果持续时间 */
				time  		: 	500,
				before 		: 	[],
				after 		: 	[]
			};

		lead = function( args ){
			var _self = this, 
				_tool,
				_config,
				_ui = { t : 0 , b : 0 , l : 0 , r : 0 , c : 0 },
				_manage;

			_tool = {
				event : {
					go : function( int ){
						var _length = _config.interviews.length;
						if( typeof int === "boolean" ){
							int = int ? _config.current++ : _config.current--;
						};
						if( _config.loop ){
							_config.current = _config.current < 0 ? ( _length - 1 ) : 
												_config.current >= _length ? 0 : _config.current;
						} else {
							_config.current = _config.current < 0 ? 0 : 
												_config.current >= _length ? _length - 1 : _config.current;
							if( int === _config.current ){
								return false;
							};
						};
						_tool.ui.go( _config.interviews[ _config.current ] );
					},
					key_board : function( e ){
						var e = e || window.event;
						switch( e.keyCode || e.which ){
							case 27:
								_manage.close();
								break;
							case 39:
								this.go( true );
								break;
							case 37:
								this.go( false );
								break;
						};
					},
					init : function(){
						_ui.containter = _config.alert_modal.parents( ".c_alert_modal" );
						_ui = $c.tool.rtn( _ui , {
							pre 	: _config.alert_modal.find( "[func='lead_pre']" ),
							next 	: _config.alert_modal.find( "[func='lead_next']" ),
							close  	: _ui.containter.find( "[func='close']" )
						} );
						_ui.pre.unbind( "click" ).click( function(){
							_manage.go( false );
						} );
						_ui.next.unbind( "click" ).click( function(){
							_manage.go( true );
						} );
						_ui.close.unbind( "click" ).click( function(){
							_manage.close();
						} );
						$( document ).keyup( function( e ){
							if( _config.display ){ _tool.event.key_board( e ); };
						} );
					}
				},
				ui : {
					set_overby : function( modal ){
						var _pos = modal.offset();
						_pos = {
							t 	: _pos.top,
							l 	: _pos.left,
							w 	: modal.outerWidth(),
							h 	: modal.outerHeight()
						};
						
						_ui.t.height( _pos.t );
						_ui.l.css( { width : _pos.l , height : _pos.h } );
						_ui.c.css( { width : _pos.w , height : _pos.h } );
						_ui.r.css( { width : ( _config.containter.width() - _pos.w - _pos.l ) , height : _pos.h } );
						_ui.b.css( { height : ( _config.containter.height() - _pos.h - _pos.t ) } );
						return _pos;
					},
					alert_move : function( pos ){
						var _css = { top : 0 , left : 0 },
							_s_pos = { w : _ui.containter.width() , h : _ui.containter.height() },
							_tmp = {
								h : ( _config.containter.height() < $c.doc.height ? _config.containter.height() : $c.doc.height ) / 2,
								w : ( _config.containter.width() < $c.doc.width ? _config.containter.width() : $c.doc.width ) / 2
							};
						if( pos.h <= _tmp.h ){
							_css.top = pos.t + Math.ceil( pos.h / 2 );
						} else {
							_css.top = pos.t + Math.ceil( pos.h / 2 ) - _s_pos.h;
						};
						if( pos.w <= _tmp.w ){
							_css.left = pos.l + pos.w + 15;
						} else if( pos.l >= _s_pos.w ){
							_css.left = pos.l - _s_pos.w - 15;
						};
						_ui.containter.stop().animate( _css , _config.time );
					},
					go : function( args ){
						var _pos = _tool.ui.set_overby( args.modal );
						if( args.title ){
							_ui.containter.find( "[func='title']" ).html( args.title );
						};
						if( args.content ){
							_config.modal.html( args.content );
						};
						if( _config.move ){ _tool.ui.alert_move( _pos ); };
						if( args.before ){
							args.before( _config.modal , _manage );
						};
						if( args.after ){
							window.setTimeout( function(){
								args.after( _config.modal , _manage );
							} , _config.time );
						};
					},
					get_overby : function(){
						var _nodes = _config.containter[ 0 ].childNodes,
							_name,
							_modal,
							_x = function(){
								_nodes = _modal.childNodes;
								for( var i = _nodes.length; i--; ){
									if( _nodes[ i ].tagName === "DIV" ){
										_ui[ _nodes[ i ].className.replace( /.*\_(.*)$/i , "$1" ) ] = $( _nodes[ i ] );
									};
								};
							};
						_config.containter.addClass( "c_lead" );
						for( var i = _nodes.length; i--; ){
							if( _nodes[ i ].tagName === "DIV" && _nodes[ i ].className.indexOf( "c_lead_overby" ) !== -1 ){
								_modal = _nodes[ i ];
								return _x();
								break;
							}; 
						};
						_modal = $( html.overby )[ 0 ];
						_config.containter.append( _modal );
						_x();
					},
					set_modal_theme_ui : function( manage ){
						var _modal = manage.info().modal[ 0 ];
						_modal.className = _modal.className.replace( /c\_lead\_theme\_.?/g , "" ) + " c_lead_theme_" + _config.theme;
					},
					set_modal : function(){
						_config.containter.addClass( "c_lead_show" );
						$c.alert.set({
							title 		: _config.title,
							content 	: _config.content,
							containter 	: _config.containter,
							drag 		: _config.drag,
							theme 		: _config.theme,
							initialize	: function( modal , _m ){
								_config.alert_modal = modal;
								_config.alert_manage = _m;
								_tool.ui.set_modal_theme_ui( _m );
								_config.modal = modal.find( "[func='interview']" ) || modal;
								if( !_config.default_ui ){
									modal.siblings( "[func='title_area']" ).remove();
								};
								_config.initialize( _config.modal , _manage );
							}
						});
					}
				},
				config : function(){
					_config = {
						containter 	: args.containter || $( "body" ),
						modal 		: args.modal,
						alert_modal : 0,
						alert_manage: 0,
						title 		: args.title || config.title,
						content 	: 0,
						default_ui 	: 0,
						theme 		: "default",
						current 	: -1,
						display 	: true,
						move 		: args.move === undefined ? config.move : args.move,
						time 		: args.time && typeof args.time === "number" ? args.time : config.time,
						drag 		: args.drag === undefined ? config.drag : args.drag,
						loop 	 	: args.loop === undefined ? true : args.loop,
						interviews	: args.interview,
						close 		: args.close && typeof args.close === "function" ? args.close : function(){},
						initialize 	: args.initialize && typeof args.initialize === "function" ? args.initialize : function(){},
					};
					_config.content = args.content || ( function(){
						_config.default_ui = true;
						_config.theme = args.theme && inner.theme[ args.theme ] ? args.theme : config.theme;
						return html.default_ui;
					} )();
					_tool.ui.set_modal();
					_tool.ui.get_overby();
					_tool.event.init();
				}
			};
			_manage = {
				config : function( args ){
					if( !args ){ return _config; };
				},
				theme : function( theme ){
					if( !theme || typeof theme !== "string" || !inner.theme[ theme ] ){ return false; };
					_config.theme = theme;
					_config.alert_manage.theme( theme );
					_tool.ui.set_modal_theme_ui( _config.alert_manage );
					return _manage;
				},
				loop : function( is_loop ){
					_config.loop = is_loop === undefined ? true : false;
					return _manage;
				},
				close : function(){
					_config.close( _config.modal , _manage );
					if( _config.alert_manage.clear ){ _config.alert_manage.clear(); };
					_config.containter.removeClass( "c_lead_show" );
					return _manage;
				},
				/*!
				 *	int : boolean 时  false 前一项  true 后一项
				 *	int : number  跳到指定的某一项
				 */
				go : function( int ){
					int = int === undefined ? true : int;
					_tool.event.go( int );
					return _manage;
				},
				pre : function(){
					this.go( false );
					return _manage;
				},
				next : function(){
					this.go( true );
					return _manage;
				}
			};
			_tool.config();
			_self.manage = _manage;
			_self.config = _config;
			return _manage;
		};

		tool = {
			data : {
				add : function( args ){
					config.leads[ config.leads.length++ ] = new lead( args );
				}
			},
			ui : {
				html : function(){
					html = {
						default_ui 	: 	'<div func="interview" class="interview">感谢！</div>\
										<div class="c_lead_footer">\
											<a class="pre" func="lead_pre">上一项</a>\
											<a class="next" func="lead_next">下一项</a>\
										</div>',
						overby 		: 	'<div class="c_lead_overby">\
											<div class="c_lead_pos_t"></div>\
											<div class="c_lead_pos_l"></div>\
											<div class="c_lead_pos_c"></div>\
											<div class="c_lead_pos_r"></div>\
											<div class="c_lead_pos_b"></div>\
										</div>'
					};
				}
			},
			init : function(){
				$( document ).ready( function(){
					tool.ui.html();
				} );
			}
		};

		manage = {

			config : function( args ){
				if( !args ){ return $c.tool.rtn( config ); };

				return manage;
			},
			/*!
			 args = {
			 	containter  : JQ_DOM,
			 	title 		: str,
				content 	: str,
				theme 		: "primary",
				time 		: 2000,
				interview  	: [
					{ 
						modal : JQDOM,
						title : str , 
						content : str , 
						before : func( modal , manage ), 
						initialize : func( modal , manage ),
						after : func( modal , manage ) 
					},
				],
				initilize 	: func( modal , manage ),
				close 		: func( modal , manage ),
				loop 		: boolean
			 };
			 */
			set : function( args ){
				if( !args || typeof args !== "object" || !args.interview ){ return false; };
				tool.data.add( args );
				return manage;
			}
		};
		tool.init();
		return manage;
	})()
});